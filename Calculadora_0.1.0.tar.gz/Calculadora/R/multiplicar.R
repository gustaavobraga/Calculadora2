#' Funcao para multiplicar
#'
#' Essa funcao serve para multiplicar dois numeros
#'
#' @param x um numero
#' @param y outro numero
#'
#' @example
#' multiplicar(2,3)

#' @export
multiplicar <- function(x, y){
  x * y
}
